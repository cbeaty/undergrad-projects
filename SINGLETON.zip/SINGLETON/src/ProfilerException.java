public class ProfilerException extends Exception {
    
    public ProfilerException() {
        super("Profiler Exception");
    }

    public ProfilerException(String msg) {
        super(msg);
    }
}