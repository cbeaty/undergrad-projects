#include <iostream>
#include <string>
#include "TicTacToeTree.h"

using namespace std;

TicTacToeTree::TicTacToeTree()
{
    totalBoards = 0;
	totalXWins = 0;
	totalOWins = 0;
	totalDraws = 0;

	root = new Node;
	root->board = new TicTacToeBoard;
	root->parent = 0;

	totalBoards++;

    descendIntoTree(root);

	cout << "Total Games: " << (totalXWins + totalOWins + totalDraws) << endl;
	cout << "X wins: " << totalXWins << endl;
	cout << "O wins: " << totalOWins << endl;
	cout << "Draw: " << totalDraws << endl << endl;
	cout << "Total Boards Created: " << totalBoards << endl;
}
//--
void TicTacToeTree::descendIntoTree(Node* parent)
{
    if (parent->board->getBoardState() == TicTacToeBoard::BOARD_STATE::INCOMPLETE_GAME)
	{
        for (int row = 0; row < parent->board->getBoardDimension(); row++)
		{
			for (int col = 0; col < parent->board->getBoardDimension(); col++)
			{
                if (parent->board->getSquare(row, col) == TicTacToeBoard::SQUARE_OCCUPANT::EMPTY)
				{
                    TicTacToeBoard* newBoard = new TicTacToeBoard(parent->board->getBoardString());
					totalBoards++;

                    if (newBoard->getPlayerTurn() == TicTacToeBoard::PLAYER_TURN::X_TURN)
					{
						newBoard->setSquare(row, col, TicTacToeBoard::X);
					}
					else
					{
						newBoard->setSquare(row, col, TicTacToeBoard::O);
					}

                    Node* newNode = new Node;
					newNode->board = newBoard;
					newNode->parent = parent;

                    parent->children.push_back(newNode);

                    descendIntoTree(newNode);
                }
            }
        }
    }
    else
    {
        if (parent->board->getBoardState() == TicTacToeBoard::BOARD_STATE::X_WIN)
		{
            totalXWins++;
        }
        else if (parent->board->getBoardState() == TicTacToeBoard::BOARD_STATE::O_WIN)
		{
            totalOWins++;
        }
        else if (parent->board->getBoardState() == TicTacToeBoard::BOARD_STATE::DRAW)
		{
			totalDraws++;
        }
    }
}
//--
TicTacToeTree::~TicTacToeTree()
{
    int numDeleted = 0;
	destructorHelper(root, numDeleted);
	cout << "Number of nodes/boards deleted " << numDeleted << endl;
}
//--
void TicTacToeTree::destructorHelper(Node* aNode, int& numDeleted)
{
	if (aNode->children.size() > 0)
	{
		for (int i = 0; i < aNode->children.size(); i++)
		{
			destructorHelper(aNode->children[i], numDeleted);
			delete aNode->children[i];				
		}
	}
	numDeleted++;
	delete aNode->board;
}