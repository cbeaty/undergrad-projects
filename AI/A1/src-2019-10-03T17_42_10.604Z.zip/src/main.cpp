#include <iostream>
#include "TicTacToeTree.h"

using namespace std;

int main()
{
	TicTacToeTree tree;

    return 0;
}