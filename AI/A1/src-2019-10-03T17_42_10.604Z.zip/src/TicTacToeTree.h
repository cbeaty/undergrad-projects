#pragma once
#include "TicTacToeBoard.h"
#include <vector>
#include <string>

using namespace std;

class TicTacToeTree
{
public:
	TicTacToeTree();
	~TicTacToeTree();

private:
	struct Node
	{
		TicTacToeBoard* board;
		vector < Node* > children;
		Node* parent;
	};

    void descendIntoTree(Node* parent);
    void destructorHelper(Node* aNode, int& numDeleted);
    
    Node* root;

    int totalBoards;
	int totalXWins;
	int totalOWins;
	int totalDraws;
};