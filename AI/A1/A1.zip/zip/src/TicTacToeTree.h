#pragma once
#include "TicTacToeBoard.h"
#include <vector>
#include <string>

using namespace std;

class TicTacToeTree
{
public:
	void breadthFirstSearchForOutcome(string boardString, TicTacToeBoard::BOARD_STATE requestedState);
	void depthFirstSearchForOutcome(string boardString, TicTacToeBoard::BOARD_STATE requestedState);

private:
	struct Node
	{
		TicTacToeBoard* board;
		vector < Node* > children;
		Node* parent;
	};

	void destructorHelper(Node* aNode);
};