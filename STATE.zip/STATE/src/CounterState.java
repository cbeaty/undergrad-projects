public class CounterState {

    public void slash(StateCounter context) {

    }

    public void star(StateCounter context) {

    }

    public void character(StateCounter context) {

    }

    public void newLine(StateCounter context) {

    }

    public void backslash(StateCounter context) {

    }

    public void doubleQuote(StateCounter context) {

    }
}